<?php
	$domainName = "ConvertJpgToPng.Online";
	$about_site = "Convert JPG to PNG Online for Free";
	$email = "webbeastyt@gmail.com";
	$url = "http://convertjpgtopng.online";
?>